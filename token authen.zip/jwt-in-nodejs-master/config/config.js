module.exports = {
    jwt_secret: "shhh"
};